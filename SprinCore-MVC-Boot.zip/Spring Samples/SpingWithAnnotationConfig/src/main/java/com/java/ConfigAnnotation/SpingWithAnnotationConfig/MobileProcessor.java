package com.java.ConfigAnnotation.SpingWithAnnotationConfig;

public interface MobileProcessor {
	
	void Processor();

}
