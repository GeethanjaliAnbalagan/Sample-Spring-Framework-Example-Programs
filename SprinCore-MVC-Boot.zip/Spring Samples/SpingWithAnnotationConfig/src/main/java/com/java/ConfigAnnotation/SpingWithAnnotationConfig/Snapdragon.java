package com.java.ConfigAnnotation.SpingWithAnnotationConfig;


public class Snapdragon implements MobileProcessor {

	@Override
	public void Processor() {
		
		System.out.println("World best deal CPU ");

	}

}
