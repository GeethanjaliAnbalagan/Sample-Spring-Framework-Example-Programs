package com.java.SpringCoreAnnotation.SpringAnnotation;

public class SpringWebIntializer {

}
