package com.java.SpringCoreAnnotation.SpringAnnotation;

public class bike implements vechile {

	public void rider()
	{
		System.out.println("Currently riding bike");
		
	}
}
