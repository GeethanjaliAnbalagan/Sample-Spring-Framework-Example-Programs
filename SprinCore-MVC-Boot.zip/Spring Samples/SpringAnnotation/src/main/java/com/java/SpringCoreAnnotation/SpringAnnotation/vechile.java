package com.java.SpringCoreAnnotation.SpringAnnotation;

public interface vechile {
	
	void rider();

}
