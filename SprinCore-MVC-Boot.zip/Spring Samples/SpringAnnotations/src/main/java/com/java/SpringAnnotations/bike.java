package com.java.SpringAnnotations;

public class bike {

	public void drive()
	{
		
		System.out.println("BIKE block");
		
	}
}
