package com.java.SpringAnnotations;

public class car {

	public void drive()
	{
		
		System.out.println("car block");
		
	}	
}
