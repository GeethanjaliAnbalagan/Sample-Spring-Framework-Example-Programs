package com.java.SpringAnnotations;

public interface vechile {
	void drive();
}
