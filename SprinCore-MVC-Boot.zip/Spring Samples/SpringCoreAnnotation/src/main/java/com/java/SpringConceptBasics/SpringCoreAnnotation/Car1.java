package com.java.SpringConceptBasics.SpringCoreAnnotation;



import org.springframework.stereotype.Component;


@Component
public class Car1 implements vechile {

	public void drive()
	
	{
		System.out.println("i m not good stressed car block");
	}

}