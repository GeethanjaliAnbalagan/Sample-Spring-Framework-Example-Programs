package com.java.SpringConceptBasics.SpringCoreAnnotation;


public class bike implements vechile  {

public void drive()
	
	{
		System.out.println("i m not good stressed bike block");
	}

}