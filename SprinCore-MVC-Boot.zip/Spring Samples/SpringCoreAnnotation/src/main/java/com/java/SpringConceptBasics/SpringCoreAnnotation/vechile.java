package com.java.SpringConceptBasics.SpringCoreAnnotation;

public interface vechile {
	
	  void drive();

}
