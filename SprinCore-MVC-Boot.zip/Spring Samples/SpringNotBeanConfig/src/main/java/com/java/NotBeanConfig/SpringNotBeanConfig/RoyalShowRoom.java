package com.java.NotBeanConfig.SpringNotBeanConfig;

public interface RoyalShowRoom {
	
	void bmw();
	void swift();
	void EcoSports();

}
