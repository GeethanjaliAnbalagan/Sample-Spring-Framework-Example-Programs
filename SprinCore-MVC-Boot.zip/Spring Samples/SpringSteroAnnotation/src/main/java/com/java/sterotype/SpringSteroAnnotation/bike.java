package com.java.sterotype.SpringSteroAnnotation;
import org.springframework.stereotype.Component;

@Component
public class bike implements vechile {
	
	public void rider()
	{
		System.out.println("You are riding bike");
		
	}

}
