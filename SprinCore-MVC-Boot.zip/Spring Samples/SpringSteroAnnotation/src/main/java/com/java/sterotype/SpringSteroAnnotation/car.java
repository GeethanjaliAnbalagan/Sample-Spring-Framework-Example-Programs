package com.java.sterotype.SpringSteroAnnotation;

import org.springframework.stereotype.Component;

@Component
public class car implements vechile {
	
	public void rider()
	{
		System.out.println("You are riding car");
		
	}

}
