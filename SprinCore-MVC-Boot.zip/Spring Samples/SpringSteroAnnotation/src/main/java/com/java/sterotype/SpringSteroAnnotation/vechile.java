package com.java.sterotype.SpringSteroAnnotation;

public interface vechile {
	void rider();

}
