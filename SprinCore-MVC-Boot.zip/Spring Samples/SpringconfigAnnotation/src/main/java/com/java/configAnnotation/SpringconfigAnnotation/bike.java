package com.java.configAnnotation.SpringconfigAnnotation;

public class bike {
	
	public void rider()
	{
		System.out.println("BIKE Rider");
		
	}

}
