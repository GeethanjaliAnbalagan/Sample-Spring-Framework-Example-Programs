package com.java.configAnnotation.SpringconfigAnnotation;

public class car {

	public void rider()
	{
		System.out.println("CAR Rider");
		
	}
	
}
