module sample {
}