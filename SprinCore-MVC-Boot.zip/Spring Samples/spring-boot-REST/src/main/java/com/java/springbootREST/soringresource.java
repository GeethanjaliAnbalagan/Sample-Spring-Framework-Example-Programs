package com.java.springbootREST;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class soringresource {
	@RequestMapping("aliens")
	public List<Alien> getAlien()
	{
		
		List<Alien> aliens = new ArrayList<>();
		
		Alien a1 = new Alien();
		a1.setId(111);
		a1.setName("geetha");
		
		
		Alien a2 = new Alien();
		a2.setId(222);
		a2.setName("sanju");
		
		aliens.add(a1);
		aliens.add(a2);
		
		
		return aliens;
		
	}
	
	
	

}
