package com.java.springbootRESTMETHODS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestmethods1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
