package com.javatechie.spring.soap.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSoapWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
