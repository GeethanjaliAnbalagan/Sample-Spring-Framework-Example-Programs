package com.javatechie.spring.soap.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSopaWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
